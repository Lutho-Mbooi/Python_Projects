
import phonenumbers

#from Find_Phone import number

from phonenumbers import geocoder
from phonenumbers import carrier
import opencage
import folium

from opencage.geocoder import OpenCageGeocode

number = input("Enter The Number")
pepnumber = phonenumbers.parse(number)
location = geocoder.description_for_number(pepnumber,"en")

print(location)

service_pro = phonenumbers.parse(number)
print(carrier.name_for_number(service_pro,"en"))

api_key = 'c74080e019ef4e4c95927762ede0727b'
geocoder = OpenCageGeocode(api_key)
query = str(location)
results = geocoder.geocode(query)

print(results)

lat = results[0]['geometry']['lat']
lng = results[0]['geometry']['lng']
print(lat, lng)

myMap = folium.Map(location=[lat, lng], zoom_start=9)
folium.Marker([lat,lng], popup=location).add_to(myMap)

myMap.save("myLoc.html")
