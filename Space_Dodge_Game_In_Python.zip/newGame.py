import pygame
import time
import random

#Initiating the Font Mod
pygame.font.init()

#setting pygame Window to draw objects

width, height = 1000,800 #Window Dimensions

window = pygame.display.set_mode((width,height))
pygame.display.set_caption("Space Dodge")

#set main game loop
#Check for game moves, collision etc

#background image

bg = pygame.image.load("Pic.jpg")
player_width = 40
player_height = 60

player_val = 5
FONT = pygame.font.SysFont("comicsans",30)  #Font Object

star_width = 10
star_height = 20
star_vel =3

def draw(player, elapsed_time, stars):
    window.blit(bg,(0,0))

    time_text = FONT.render(f"Time: {round(elapsed_time)}s",1,"white")

    window.blit(time_text,(10,10)) #Position to write time


    pygame.draw.rect(window,"red",player)

    for star in stars:
        pygame.draw.rect(window,"white",star)

    pygame.display.update()


def main():
    run = True

    #Create Character
    player = pygame.Rect(200,height-player_height,player_width,player_height)
    clock = pygame.time.Clock()

    #keep track of time elapsed
    Start_time = time.time()
    elapsed_time=0

    #Adding projectiles
    star_add_increment = 200
    star_count = 0

    stars = [] # store stars currently on screen
    hit = False

    while run:
        #timer
        star_count += clock.tick(60) #count how many seconds since the last clock tick

        elapsed_time = time.time()- Start_time

        if star_count> star_add_increment:
            for _  in range(3):
                star_x = random.randint(0,width - star_width)
                star = pygame.Rect(star_x, -star_height,star_width,star_height)
                stars.append(star)
                star_add_increment = max(200,star_add_increment-50)

                star_count =0

        #handle keypresses
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                break

        #Listen to keyboard and monitor bounderies not to exceed the game world
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT] and player.x-player_val>=0:
            player.x -= player_val #velocity
        
        if key[pygame.K_RIGHT] and player.x+player_val + player.width<= width:
            player.x += player_val #velocity

        #Moving projectiles and Collisions
        for star in stars[:]:
            star.y += star_vel  #Star Velocity
            if star.y > height:
                stars.remove(star)
            elif star.y + star.height>= player.y and star.colliderect(player): #check if star collides with the player or its in the lower y co-ord

                stars.remove(star)
                hit = True
                break

        if hit:
            lost_text = FONT.render("Game Over!!!!",1,"red")
            window.blit(lost_text,(width/2-lost_text.get_width()/2,height/2-lost_text.get_height()/2))
            pygame.display.update()
            pygame.time.delay(4000)
            break

        draw(player,elapsed_time,stars)
    pygame.quit()

if __name__ == "__main__":
    main()